﻿using System.Xml;
using ThomsonReuters.Eikon.Integration;

/*
 * WARNING: This App Studio template does not contain the nuget packages. Right-click on the solution, select
 * "Enable NuGet Package Restore" and select Yes. After that select Build, Build Solution in the Visual Studio menu bar.
 * 
 * NuGet will do restore the missing packages.
 * 
 */

namespace show_pop_up_eikon
{
    /// <summary>
    /// An App Studio application template. The <see cref="EikonAppStart"/> attribute specifies the main control of your app.
    /// </summary>
    [EikonAppStart]
    public partial class MainControl
    {
        #region IAppHost

        public IAppHost AppHost { get; private set; }

        /// <summary>The default constructor.</summary>
        public MainControl()
        {
            InitializeComponent();
        }

        /// <summary>The default entry point for the app, when the user opens it from the App Library.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        public MainControl(IAppHost appHost)
            : this()
        {
            AppHost = appHost;
            AppHost.Closing += AppHostOnClosing;
        }

        /// <summary>The entry point for the app, opened as a part of a saved workspace with the state, that you have previously serialized.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="settingsReader">An instance of <see cref="System.Xml.XmlReader"/> with the previously serialized state.</param>
        public MainControl(IAppHost appHost, XmlReader settingsReader)
            : this(appHost)
        {

        }

        /// <summary>The entry point for the app, opened from the Related right-click menu or other navigation operation.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="context">An instance of <see cref="ThomsonReuters.Eikon.Integration.IContext"/> providing an identifier and other properties for one or many instruments in the context.</param>
        public MainControl(IAppHost appHost, IContext context)
            : this(appHost)
        {

        }

        /// <summary>The <see cref="IAppHost.Closing"/> event handler.</summary>
        /// <param name="sender">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="closingEventArgs">Closing event arguments.</param>
        private void AppHostOnClosing(object sender, ClosingEventArgs closingEventArgs)
        {

        }

        #endregion
    }
}
